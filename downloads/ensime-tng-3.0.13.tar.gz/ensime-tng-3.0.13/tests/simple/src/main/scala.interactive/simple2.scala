package simple

import java.lang.String

object Main {

  def main(args: Array[String]): Unit = {
    Foo.
  }

}
