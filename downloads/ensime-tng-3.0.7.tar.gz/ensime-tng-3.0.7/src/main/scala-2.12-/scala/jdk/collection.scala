// Copyright: Sam Halliday
// License: GPLv3+
package scala.jdk

import scala.collection.convert._

object CollectionConverters extends DecorateAsJava with DecorateAsScala
