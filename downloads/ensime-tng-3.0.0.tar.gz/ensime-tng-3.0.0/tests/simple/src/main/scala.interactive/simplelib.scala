package simple

object Foo {
  val foo: List[Boolean] = List(true, false)

  val bar: String = "bar"
}
